This a little "throw-away" utility I used to crunch a monochrome HackADay logo (http://hackaday.com) into something
small enough to include in the benchmark.  See "graphictest" example for how to decompress.

It is messily hacked together, so beware (originally from an Arduino composite video sprite library "cruncher" https://www.youtube.com/watch?v=Imk5ony8JHI that is still a W.I.P.)

Thanks Hack-A-Day (for your cool logo - please don't sue me...)
